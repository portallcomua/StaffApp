/* StaffApp Vision 4.2.3 — стійке розпізнавання облич і номерів авто.
 * Ставиться поверх @vladmandic/face-api (містить сумісний tfjs) + Tesseract.js.
 * Нічого не змінює в решті плагіна: експортує лише window.SAVision.
 */
(function () {
  'use strict';
  var F = null;
  var ready = false;
  var log = function (m) { try { console.log('[SAVision] ' + m); } catch (e) {} };

  function api() { return window.faceapi || null; }

  async function load(modelUrl, dbg) {
    dbg = dbg || log;
    F = api();
    if (!F) throw new Error('face-api не завантажився');
    var url = modelUrl || 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.15/model';
    await F.nets.ssdMobilenetv1.loadFromUri(url).catch(function (e) { dbg('ssd: ' + e.message); });
    await F.nets.tinyFaceDetector.loadFromUri(url);
    await F.nets.faceLandmark68Net.loadFromUri(url);
    await F.nets.faceRecognitionNet.loadFromUri(url);
    ready = true;
    dbg('Моделі облич завантажені: ' + url);
    return true;
  }

  function isReady() { return ready; }

  function toImage(src) {
    return new Promise(function (res, rej) {
      var i = new Image();
      i.crossOrigin = 'anonymous';
      i.onload = function () { res(i); };
      i.onerror = function () { rej(new Error('Фото не читається')); };
      i.src = src;
    });
  }

  /* Малює джерело у canvas із фільтром/масштабом/дзеркалом. */
  function toCanvas(src, opt) {
    opt = opt || {};
    var maxW = opt.maxW || 960;
    var w = src.videoWidth || src.naturalWidth || src.width;
    var h = src.videoHeight || src.naturalHeight || src.height;
    if (!w || !h) return null;
    if (w > maxW) { h = Math.round(h * maxW / w); w = maxW; }
    var c = document.createElement('canvas');
    c.width = w; c.height = h;
    var x = c.getContext('2d');
    if (opt.filter) x.filter = opt.filter;
    if (opt.mirror) { x.translate(w, 0); x.scale(-1, 1); }
    x.drawImage(src, 0, 0, w, h);
    return c;
  }

  /* Фільтри під різне освітлення: темрява, пересвіт, контражур, окуляри/кепка. */
  var FACE_FILTERS = [
    '',
    'contrast(1.35) brightness(1.15)',
    'brightness(1.55) contrast(1.15)',
    'brightness(0.8) contrast(1.45)',
    'grayscale(1) contrast(1.6)'
  ];

  function detectors() {
    var out = [];
    if (F.nets.ssdMobilenetv1.isLoaded) out.push(new F.SsdMobilenetv1Options({ minConfidence: 0.25 }));
    out.push(new F.TinyFaceDetectorOptions({ inputSize: 512, scoreThreshold: 0.25 }));
    out.push(new F.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.2 }));
    return out;
  }

  /* Кілька облич у кадрі: беремо найкращий прохід (найбільше знайдених). */
  async function detectAll(src) {
    if (!ready) throw new Error('Моделі ще не готові');
    var best = [];
    for (var fi = 0; fi < FACE_FILTERS.length; fi++) {
      var c = toCanvas(src, { filter: FACE_FILTERS[fi], maxW: 1024 });
      if (!c) continue;
      var opts = detectors();
      for (var oi = 0; oi < opts.length; oi++) {
        var dets = await F.detectAllFaces(c, opts[oi]).withFaceLandmarks().withFaceDescriptors();
        if (dets.length > best.length) best = dets;
        if (best.length >= 2) return best;
      }
      if (best.length) return best;
    }
    return best;
  }

  /* Енролмент: з одного фото — кілька дескрипторів (фільтри + дзеркало). */
  async function descriptors(dataUrl, maxVariants) {
    if (!ready) return [];
    var img = await toImage(dataUrl);
    var out = [];
    var limit = maxVariants || 4;
    var variants = [
      { filter: '', mirror: false },
      { filter: '', mirror: true },
      { filter: 'contrast(1.35) brightness(1.12)', mirror: false },
      { filter: 'brightness(1.5)', mirror: false },
      { filter: 'grayscale(1) contrast(1.5)', mirror: false }
    ];
    for (var i = 0; i < variants.length && out.length < limit; i++) {
      var c = toCanvas(img, { filter: variants[i].filter, mirror: variants[i].mirror, maxW: 800 });
      if (!c) continue;
      var opts = detectors();
      for (var oi = 0; oi < opts.length; oi++) {
        var d = await F.detectSingleFace(c, opts[oi]).withFaceLandmarks().withFaceDescriptor();
        if (d) { out.push(Array.from(d.descriptor)); break; }
      }
    }
    return out;
  }

  /* ---------- OCR номерів ---------- */

  function grayBin(canvas, mode) {
    var x = canvas.getContext('2d');
    var d = x.getImageData(0, 0, canvas.width, canvas.height);
    var p = d.data, i, g, sum = 0, n = canvas.width * canvas.height;
    var hist = new Array(256).fill(0);
    for (i = 0; i < p.length; i += 4) {
      g = (p[i] * 0.299 + p[i + 1] * 0.587 + p[i + 2] * 0.114) | 0;
      p[i] = p[i + 1] = p[i + 2] = g;
      hist[g]++; sum += g;
    }
    if (mode === 'gray') { x.putImageData(d, 0, 0); return canvas; }
    var thr;
    if (mode === 'otsu') {
      var total = n, sumB = 0, wB = 0, max = -1; thr = 128;
      for (i = 0; i < 256; i++) {
        wB += hist[i]; if (!wB) continue;
        var wF = total - wB; if (!wF) break;
        sumB += i * hist[i];
        var mB = sumB / wB, mF = (sum - sumB) / wF;
        var between = wB * wF * (mB - mF) * (mB - mF);
        if (between > max) { max = between; thr = i; }
      }
    } else { thr = (sum / n) | 0; }
    for (i = 0; i < p.length; i += 4) {
      var v = p[i] > thr ? 255 : 0;
      p[i] = p[i + 1] = p[i + 2] = v;
    }
    x.putImageData(d, 0, 0);
    return canvas;
  }

  /* Обрізка кадру: центральна зона (де зазвичай номер) без синіх смуг UA. */
  /* Розтягування контрасту по перцентилях: врятовує темні/пересвічені кадри. */
  function stretch(canvas) {
    var x = canvas.getContext('2d');
    var d = x.getImageData(0, 0, canvas.width, canvas.height), p = d.data;
    var hist = new Array(256).fill(0), i, g;
    for (i = 0; i < p.length; i += 4) {
      g = (p[i] * 0.299 + p[i + 1] * 0.587 + p[i + 2] * 0.114) | 0;
      p[i] = p[i + 1] = p[i + 2] = g; hist[g]++;
    }
    var total = canvas.width * canvas.height, lo = 0, hi = 255, acc = 0;
    for (i = 0; i < 256; i++) { acc += hist[i]; if (acc > total * 0.02) { lo = i; break; } }
    acc = 0;
    for (i = 255; i >= 0; i--) { acc += hist[i]; if (acc > total * 0.02) { hi = i; break; } }
    if (hi - lo < 12) { hi = Math.min(255, lo + 12); }
    var k = 255 / (hi - lo);
    for (i = 0; i < p.length; i += 4) {
      var v = Math.max(0, Math.min(255, (p[i] - lo) * k));
      p[i] = p[i + 1] = p[i + 2] = v;
    }
    x.putImageData(d, 0, 0);
    return canvas;
  }

  /* Автопошук зони номера: найяскравіша витягнута область кадру. */
  function locate(img) {
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    var sw = 240, sh = Math.max(1, Math.round(h * sw / w));
    var c = document.createElement('canvas');
    c.width = sw; c.height = sh;
    var x = c.getContext('2d');
    x.drawImage(img, 0, 0, sw, sh);
    stretch(c);
    var d = x.getImageData(0, 0, sw, sh).data;
    var rows = new Array(sh).fill(0), cols = new Array(sw).fill(0), count = 0;
    for (var y = 0; y < sh; y++) {
      for (var xx = 0; xx < sw; xx++) {
        if (d[(y * sw + xx) * 4] > 190) { rows[y]++; cols[xx]++; count++; }
      }
    }
    if (count < sw * sh * 0.01) return null;
    function span(arr, limit) {
      var a = -1, b = -1;
      for (var i = 0; i < arr.length; i++) if (arr[i] > limit) { if (a < 0) a = i; b = i; }
      return [a, b];
    }
    var ry = span(rows, sw * 0.06), rx = span(cols, sh * 0.06);
    if (ry[0] < 0 || rx[0] < 0) return null;
    var bw = (rx[1] - rx[0]) / sw, bh = (ry[1] - ry[0]) / sh;
    if (bw < 0.12 || bh < 0.03) return null;
    var padX = bw * 0.08, padY = bh * 0.25;
    return [
      Math.max(0, rx[0] / sw - padX),
      Math.max(0, ry[0] / sh - padY),
      Math.min(1, bw + padX * 2),
      Math.min(1, bh + padY * 2)
    ];
  }

  function crop(img, box, scale) {
    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
    var sx = Math.round(w * box[0]), sy = Math.round(h * box[1]);
    var sw = Math.round(w * box[2]), sh = Math.round(h * box[3]);
    if (sw < 8 || sh < 8) return null;
    var k = scale || 2;
    if (sw * k > 1600) k = Math.max(1, 1600 / sw);
    var c = document.createElement('canvas');
    c.width = Math.round(sw * k); c.height = Math.round(sh * k);
    var x = c.getContext('2d');
    x.imageSmoothingQuality = 'high';
    x.drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
    return stretch(c);
  }


  function rotate(canvas, deg) {
    var r = deg * Math.PI / 180;
    var c = document.createElement('canvas');
    c.width = canvas.width; c.height = canvas.height;
    var x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    x.translate(c.width / 2, c.height / 2); x.rotate(r);
    x.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
    return c;
  }

  /* Обрізка до світлого тіла номера: відкидаємо темне тло навколо пластини. */
  function whiteCrop(canvas) {
    var x = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    var d = x.getImageData(0, 0, w, h).data;
    var minX = w, minY = h, maxX = -1, maxY = -1, light = 0;
    for (var y = 0; y < h; y++) {
      for (var xx = 0; xx < w; xx++) {
        if (d[(y * w + xx) * 4] > 160) {
          light++;
          if (xx < minX) minX = xx; if (xx > maxX) maxX = xx;
          if (y < minY) minY = y; if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX < 0 || light < w * h * 0.05) return canvas;
    var bw = maxX - minX, bh = maxY - minY;
    if (bw < 20 || bh < 10) return canvas;
    var ix = Math.round(bw * 0.02), iy = Math.round(bh * 0.04);
    var sx = minX + ix, sy = minY + iy, sw = bw - ix * 2, sh = bh - iy * 2;
    if (sw < 20 || sh < 10) return canvas;
    var c = document.createElement('canvas');
    c.width = sw; c.height = sh;
    var cx = c.getContext('2d');
    cx.fillStyle = '#fff'; cx.fillRect(0, 0, sw, sh);
    cx.drawImage(canvas, sx, sy, sw, sh, 0, 0, sw, sh);
    return c;
  }

  /* Обрізка по чорнилу: лишаємо тільки символи і збільшуємо їх до читабельного розміру. */
  function inkCrop(canvas) {
    var x = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    var d = x.getImageData(0, 0, w, h).data;
    var minX = w, minY = h, maxX = -1, maxY = -1, dark = 0;
    for (var y = 0; y < h; y++) {
      for (var xx = 0; xx < w; xx++) {
        if (d[(y * w + xx) * 4] < 96) {
          dark++;
          if (xx < minX) minX = xx; if (xx > maxX) maxX = xx;
          if (y < minY) minY = y; if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX < 0 || dark < 20) return canvas;
    var bw = maxX - minX, bh = maxY - minY;
    if (bw < 10 || bh < 6 || bw > w * 0.99) return canvas;
    var padX = Math.round(bh * 0.4), padY = Math.round(bh * 0.35);
    var sx = Math.max(0, minX - padX), sy = Math.max(0, minY - padY);
    var sw = Math.min(w - sx, bw + padX * 2), sh = Math.min(h - sy, bh + padY * 2);
    var k = Math.min(6, Math.max(1, 110 / sh));
    var c = document.createElement('canvas');
    c.width = Math.round(sw * k); c.height = Math.round(sh * k);
    var cx = c.getContext('2d');
    cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height);
    cx.imageSmoothingQuality = 'high';
    cx.drawImage(canvas, sx, sy, sw, sh, 0, 0, c.width, c.height);
    return c;
  }

  /* Оцінка нахилу: беремо кут, при якому рядок символів найрівніший. */
  function bestAngle(canvas) {
    var cand = [0, -4, 4, -8, 8, -12, 12, -18, 18];
    var best = 0, bestScore = -1;
    for (var i = 0; i < cand.length; i++) {
      var c = cand[i] ? rotate(canvas, cand[i]) : canvas;
      var x = c.getContext('2d');
      var w = c.width, h = c.height;
      var d = x.getImageData(0, 0, w, h).data;
      var rows = new Array(h).fill(0), total = 0;
      for (var y = 0; y < h; y++) {
        for (var xx = 0; xx < w; xx++) if (d[(y * w + xx) * 4] < 96) { rows[y]++; total++; }
      }
      if (!total) continue;
      var mean = total / h, varr = 0;
      for (var y2 = 0; y2 < h; y2++) varr += (rows[y2] - mean) * (rows[y2] - mean);
      varr /= h;
      if (varr > bestScore) { bestScore = varr; best = cand[i]; }
    }
    return best;
  }

  var LAT2CYR = { A: 'А', B: 'В', C: 'С', E: 'Е', H: 'Н', I: 'І', K: 'К', M: 'М', O: 'О', P: 'Р', T: 'Т', X: 'Х' };
  var UA_LETTERS = 'АВЕІКМНОРСТХ';

  function normalize(raw) {
    var t = (raw || '').toUpperCase().replace(/[^A-ZА-ЯІЇЄ0-9]/g, '');
    var out = '';
    for (var i = 0; i < t.length; i++) out += (LAT2CYR[t[i]] || t[i]);
    return out;
  }

  /* Виправлення типових помилок OCR за позицією в масці АА 0000 АА. */
  function fixByMask(s) {
    if (s.length !== 8) return s;
    var d2l = { '0': 'О', '1': 'І', '4': 'А', '6': 'В', '8': 'В', '5': 'С', '7': 'Т', '3': 'В' };
    var l2d = { 'О': '0', 'І': '1', 'З': '3', 'В': '8', 'Б': '6', 'S': '5' };
    var r = '';
    for (var i = 0; i < 8; i++) {
      var ch = s[i];
      if (i < 2 || i > 5) r += (/[0-9]/.test(ch) ? (d2l[ch] || ch) : ch);
      else r += (/[0-9]/.test(ch) ? ch : (l2d[ch] || ch));
    }
    return r;
  }

  function extract(text) {
    var t = normalize(text);
    var m = t.match(/[А-ЯІЇЄ]{2}\d{4}[А-ЯІЇЄ]{2}/);
    if (m) return m[0];
    m = t.match(/[А-ЯІЇЄ0-9]{8}/);
    if (m) {
      var f = fixByMask(m[0]);
      if (/^[А-ЯІЇЄ]{2}\d{4}[А-ЯІЇЄ]{2}$/.test(f)) return f;
    }
    return '';
  }

  function score(plate) {
    if (!plate) return 0;
    var s = 1;
    for (var i = 0; i < 2; i++) if (UA_LETTERS.indexOf(plate[i]) >= 0) s++;
    for (var j = 6; j < 8; j++) if (UA_LETTERS.indexOf(plate[j]) >= 0) s++;
    return s;
  }

  /* Кілька проходів (зони кадру × бінаризація × нахил) + голосування. */
  async function readPlate(dataUrl, dbg) {
    dbg = dbg || log;
    if (!window.Tesseract) throw new Error('OCR не завантажився');
    var img = await toImage(dataUrl);
    var boxes = [];
    var found = locate(img);
    if (found) { boxes.push(found); dbg('зона номера знайдена автоматично'); }
    boxes.push([0.10, 0.28, 0.80, 0.44], [0.0, 0.0, 1, 1], [0.18, 0.38, 0.64, 0.30]);
    var modes = ['otsu', 'gray'];
    var votes = {};
    var segs = ['7', '6'];
    for (var b = 0; b < boxes.length; b++) {
      for (var m = 0; m < modes.length; m++) {
        var cropped = crop(img, boxes[b], 3);
        if (!cropped) continue;
        var base = grayBin(cropped, modes[m]);
        var tight = inkCrop(whiteCrop(base));
        var skew = bestAngle(tight);
        var angles = skew ? [skew, 0] : [0, -7];
        for (var a = 0; a < angles.length; a++) {
          var c = angles[a] ? inkCrop(whiteCrop(grayBin(rotate(tight, angles[a]), 'otsu'))) : tight;
          for (var sg = 0; sg < segs.length; sg++) {
            var res;
            var cfg = {
              tessedit_char_whitelist: 'ABCEHIKMOPTXАВЕІКМНОРСТХ0123456789',
              tessedit_pageseg_mode: segs[sg]
            };
            try { res = await window.Tesseract.recognize(c.toDataURL('image/png'), 'eng', cfg); }
            catch (e) { dbg('OCR pass error: ' + e.message); continue; }
            var plate = extract(res.data && res.data.text);
            if (!plate) continue;
            var conf = (res.data.confidence || 50) / 100;
            votes[plate] = (votes[plate] || 0) + conf + score(plate) * 0.2;
            dbg('OCR прохід → ' + plate + ' (conf ' + Math.round(conf * 100) + '%)');
            if (votes[plate] >= 1.8) return plate;
          }
        }
      }
    }

    var bestPlate = '', bestVal = 0;
    Object.keys(votes).forEach(function (k) { if (votes[k] > bestVal) { bestVal = votes[k]; bestPlate = k; } });
    return bestPlate;
  }

  window.SAVision = {
    load: load,
    isReady: isReady,
    detectAll: detectAll,
    descriptors: descriptors,
    readPlate: readPlate,
    toImage: toImage,
    normalizePlate: normalize
  };
})();
