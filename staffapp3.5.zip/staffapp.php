<?php
/**
 * Plugin Name: StaffApp
 * Plugin URI: https://your-site.com/staffapp
 * Description: Система обліку персоналу з розпізнаванням облич. Додавання працівників, фіксація приходу/виходу, звільнення, експорт в Excel.
 * Version: 3.5
 * Author: Your Name
 * Author URI: https://your-site.com
 * License: GPL v2 or later
 * Text Domain: staffapp
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// АКТИВАЦІЯ
// ============================================
register_activation_hook(__FILE__, 'staffapp_install');
function staffapp_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $table_employees = $wpdb->prefix . 'staffapp_employees';
    $sql1 = "CREATE TABLE IF NOT EXISTS $table_employees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pib VARCHAR(255) NOT NULL,
        posada VARCHAR(255) NOT NULL,
        date_in DATE,
        date_out DATE,
        main_photo TEXT,
        photos LONGTEXT,
        descriptors LONGTEXT,
        fired BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate";
    
    $table_attendance = $wpdb->prefix . 'staffapp_attendance';
    $sql2 = "CREATE TABLE IF NOT EXISTS $table_attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        emp_id INT,
        emp_name VARCHAR(255),
        date DATE,
        time TIME,
        type VARCHAR(10),
        guard_name VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate";
    
    $table_guards = $wpdb->prefix . 'staffapp_guards';
    $sql4 = "CREATE TABLE IF NOT EXISTS $table_guards (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate";
    
    $table_settings = $wpdb->prefix . 'staffapp_settings';
    $sql3 = "CREATE TABLE IF NOT EXISTS $table_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(255) UNIQUE,
        setting_value TEXT
    ) $charset_collate";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql1);
    dbDelta($sql2);
    dbDelta($sql3);
    dbDelta($sql4);
    
    $exists = $wpdb->get_var("SELECT COUNT(*) FROM $table_settings WHERE setting_key = 'manager_password'");
    if (!$exists) {
        $wpdb->insert($table_settings, ['setting_key' => 'manager_password', 'setting_value' => wp_hash_password('1111')]);
    }
    
    // Створюємо папку для фото
    $upload_dir = wp_upload_dir();
    $staffapp_dir = $upload_dir['basedir'] . '/staffapp_photos';
    if (!file_exists($staffapp_dir)) {
        wp_mkdir_p($staffapp_dir);
    }
    
    staffapp_create_page();
}

function staffapp_create_page() {
    $page_title = 'StaffApp';
    $page_content = '[staffapp]';
    $page_check = get_page_by_title($page_title);
    if (!$page_check) {
        wp_insert_post([
            'post_title' => $page_title,
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_name' => 'staffapp'
        ]);
    }
}

// ============================================
// REST API
// ============================================
add_action('rest_api_init', 'staffapp_register_routes');
function staffapp_register_routes() {
    register_rest_route('staffapp/v1', '/employees', ['methods' => 'GET', 'callback' => 'staffapp_get_employees', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/employee', ['methods' => 'POST', 'callback' => 'staffapp_save_employee', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/upload_photo', ['methods' => 'POST', 'callback' => 'staffapp_upload_photo', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/fire', ['methods' => 'POST', 'callback' => 'staffapp_fire_employee', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/restore', ['methods' => 'POST', 'callback' => 'staffapp_restore_employee', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/delete', ['methods' => 'POST', 'callback' => 'staffapp_delete_employee', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/attendance', ['methods' => 'POST', 'callback' => 'staffapp_save_attendance', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/attendance', ['methods' => 'GET', 'callback' => 'staffapp_get_attendance', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/attendance/by_employee', ['methods' => 'GET', 'callback' => 'staffapp_get_attendance_by_employee', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/login', ['methods' => 'POST', 'callback' => 'staffapp_login', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/guards', ['methods' => 'GET', 'callback' => 'staffapp_get_guards', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/guard', ['methods' => 'POST', 'callback' => 'staffapp_save_guard', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/guard/update', ['methods' => 'POST', 'callback' => 'staffapp_update_guard', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/guard/delete', ['methods' => 'POST', 'callback' => 'staffapp_delete_guard', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/export/employees', ['methods' => 'GET', 'callback' => 'staffapp_export_employees', 'permission_callback' => '__return_true']);
    register_rest_route('staffapp/v1', '/export/attendance', ['methods' => 'GET', 'callback' => 'staffapp_export_attendance', 'permission_callback' => '__return_true']);
}

function staffapp_get_employees() {
    global $wpdb;
    $employees = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}staffapp_employees ORDER BY pib");
    $upload_url = wp_upload_dir()['baseurl'] . '/staffapp_photos/';
    foreach ($employees as $e) {
        if ($e->main_photo && !filter_var($e->main_photo, FILTER_VALIDATE_URL)) {
            $e->main_photo = $upload_url . $e->main_photo;
        }
        $photos = json_decode($e->photos, true);
        if (is_array($photos)) {
            $e->photos = array_map(function($p) use ($upload_url) {
                return filter_var($p, FILTER_VALIDATE_URL) ? $p : $upload_url . $p;
            }, $photos);
        }
        if (is_string($e->descriptors)) {
            $e->descriptors = json_decode($e->descriptors, true);
        }
    }
    return rest_ensure_response($employees);
}

function staffapp_upload_photo($request) {
    $data = $request->get_json_params();
    $base64 = $data['photo'];
    $employee_id = $data['employee_id'] ?? 'temp';
    
    $image_data = explode(',', $base64);
    if (count($image_data) < 2) {
        return rest_ensure_response(['success' => false, 'error' => 'Invalid image data']);
    }
    $image = base64_decode($image_data[1]);
    
    $filename = 'emp_' . $employee_id . '_' . time() . '_' . uniqid() . '.jpg';
    
    $upload_dir = wp_upload_dir()['basedir'] . '/staffapp_photos/';
    if (!file_exists($upload_dir)) {
        wp_mkdir_p($upload_dir);
    }
    
    $filepath = $upload_dir . $filename;
    file_put_contents($filepath, $image);
    
    return rest_ensure_response(['success' => true, 'filename' => $filename]);
}

function staffapp_save_employee($request) {
    global $wpdb;
    $data = $request->get_json_params();
    
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}staffapp_employees WHERE pib = %s", $data['pib']));
    
    $descriptors = isset($data['descriptors']) ? json_encode($data['descriptors']) : '[]';
    $photos = isset($data['photos']) ? json_encode($data['photos']) : '[]';
    $main_photo = isset($data['main_photo']) ? $data['main_photo'] : '';
    
    if ($exists) {
        $wpdb->update($wpdb->prefix . 'staffapp_employees', [
            'posada' => sanitize_text_field($data['posada']),
            'date_in' => $data['date_in'],
            'main_photo' => $main_photo,
            'photos' => $photos,
            'descriptors' => $descriptors,
            'fired' => 0,
            'date_out' => null
        ], ['id' => $exists]);
        return rest_ensure_response(['success' => true, 'id' => $exists]);
    }
    
    $result = $wpdb->insert($wpdb->prefix . 'staffapp_employees', [
        'pib' => sanitize_text_field($data['pib']),
        'posada' => sanitize_text_field($data['posada']),
        'date_in' => $data['date_in'],
        'date_out' => null,
        'main_photo' => $main_photo,
        'photos' => $photos,
        'descriptors' => $descriptors,
        'fired' => 0
    ]);
    
    if ($result) {
        return rest_ensure_response(['success' => true, 'id' => $wpdb->insert_id]);
    } else {
        return rest_ensure_response(['success' => false, 'error' => $wpdb->last_error]);
    }
}

function staffapp_fire_employee($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $today = date('Y-m-d');
    $wpdb->update($wpdb->prefix . 'staffapp_employees', [
        'date_out' => $today,
        'fired' => 1
    ], ['id' => intval($data['id'])]);
    return rest_ensure_response(['success' => true]);
}

function staffapp_restore_employee($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $wpdb->update($wpdb->prefix . 'staffapp_employees', [
        'date_out' => null,
        'fired' => 0
    ], ['id' => intval($data['id'])]);
    return rest_ensure_response(['success' => true]);
}

function staffapp_delete_employee($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $wpdb->delete($wpdb->prefix . 'staffapp_attendance', ['emp_id' => intval($data['id'])]);
    $wpdb->delete($wpdb->prefix . 'staffapp_employees', ['id' => intval($data['id'])]);
    return rest_ensure_response(['success' => true]);
}

function staffapp_save_attendance($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $result = $wpdb->insert($wpdb->prefix . 'staffapp_attendance', [
        'emp_id' => intval($data['emp_id']),
        'emp_name' => sanitize_text_field($data['emp_name']),
        'date' => current_time('Y-m-d'),
        'time' => current_time('H:i:s'),
        'type' => $data['type'],
        'guard_name' => sanitize_text_field($data['guard_name'])
    ]);
    return rest_ensure_response(['success' => $result]);
}

function staffapp_get_attendance($request) {
    global $wpdb;
    $date = $request->get_param('date') ?: current_time('Y-m-d');
    return rest_ensure_response($wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}staffapp_attendance WHERE date = %s ORDER BY time DESC", $date)));
}

function staffapp_get_attendance_by_employee($request) {
    global $wpdb;
    $emp_id = intval($request->get_param('emp_id'));
    return rest_ensure_response($wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}staffapp_attendance WHERE emp_id = %d ORDER BY date DESC, time DESC", $emp_id)));
}

function staffapp_login($request) {
    global $wpdb;
    $data = $request->get_json_params();
    
    if ($data['role'] === 'manager') {
        $stored = $wpdb->get_var("SELECT setting_value FROM {$wpdb->prefix}staffapp_settings WHERE setting_key = 'manager_password'");
        if (wp_check_password($data['password'], $stored)) {
            return rest_ensure_response(['success' => true, 'role' => 'manager']);
        }
    } else {
        $guards = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}staffapp_guards");
        foreach ($guards as $guard) {
            if (wp_check_password($data['password'], $guard->password)) {
                return rest_ensure_response(['success' => true, 'role' => 'guard', 'name' => $guard->name, 'id' => $guard->id]);
            }
        }
    }
    return rest_ensure_response(['success' => false]);
}

function staffapp_get_guards() {
    global $wpdb;
    return rest_ensure_response($wpdb->get_results("SELECT id, name, created_at FROM {$wpdb->prefix}staffapp_guards ORDER BY created_at DESC"));
}

function staffapp_save_guard($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $result = $wpdb->insert($wpdb->prefix . 'staffapp_guards', [
        'name' => sanitize_text_field($data['name']),
        'password' => wp_hash_password($data['password'])
    ]);
    return rest_ensure_response(['success' => $result, 'id' => $wpdb->insert_id]);
}

function staffapp_update_guard($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $result = $wpdb->update($wpdb->prefix . 'staffapp_guards', [
        'password' => wp_hash_password($data['password'])
    ], ['id' => intval($data['id'])]);
    return rest_ensure_response(['success' => $result]);
}

function staffapp_delete_guard($request) {
    global $wpdb;
    $data = $request->get_json_params();
    $result = $wpdb->delete($wpdb->prefix . 'staffapp_guards', ['id' => intval($data['id'])]);
    return rest_ensure_response(['success' => $result]);
}

function staffapp_export_employees() {
    global $wpdb;
    $employees = $wpdb->get_results("SELECT id, pib, posada, date_in, date_out, fired FROM {$wpdb->prefix}staffapp_employees ORDER BY pib");
    $csv = "ID,ПІБ,Посада,Дата прийняття,Дата звільнення,Статус\n";
    foreach ($employees as $e) {
        $csv .= "\"{$e->id}\",\"{$e->pib}\",\"{$e->posada}\",\"{$e->date_in}\",\"" . ($e->date_out ?: '—') . "\",\"" . ($e->fired ? 'Звільнений' : 'Активний') . "\"\n";
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="employees_' . date('Y-m-d') . '.csv"');
    echo "\xEF\xBB\xBF" . $csv;
    exit;
}

function staffapp_export_attendance() {
    global $wpdb;
    $date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : date('Y-m-d');
    $attendance = $wpdb->get_results($wpdb->prepare(
        "SELECT a.*, e.posada FROM {$wpdb->prefix}staffapp_attendance a LEFT JOIN {$wpdb->prefix}staffapp_employees e ON a.emp_id = e.id WHERE a.date = %s ORDER BY a.time DESC", $date
    ));
    $csv = "ПІБ,Посада,Дата,Час,Подія,Охоронець\n";
    foreach ($attendance as $a) {
        $csv .= "\"{$a->emp_name}\",\"{$a->posada}\",\"{$a->date}\",\"{$a->time}\",\"" . ($a->type == 'in' ? 'Прийшов' : 'Пішов') . "\",\"{$a->guard_name}\"\n";
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="attendance_' . $date . '.csv"');
    echo "\xEF\xBB\xBF" . $csv;
    exit;
}

// ============================================
// ШОРТКОД (HTML + JS)
// ============================================
add_shortcode('staffapp', 'staffapp_frontend');
function staffapp_frontend() {
    ob_start();
    ?>
    <div id="staffapp-root">
        <div style="text-align: center; padding: 50px; font-family: system-ui;">
            <div style="font-size: 28px; font-weight: bold; margin-bottom: 20px;">ПРОХІДНА</div>
            <div style="width: 200px; height: 3px; background: #ccc; margin: 0 auto 10px; border-radius: 2px; overflow: hidden;">
                <div style="width: 50%; height: 100%; background: #3b82f6;"></div>
            </div>
            <div>Завантаження системи...</div>
        </div>
    </div>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Manrope:wght@300;400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .staffapp-screen { display: none; min-height: 100vh; flex-direction: column; background: #0d0f14; font-family: 'Manrope', sans-serif; color: #e8eaf0; }
        .staffapp-screen.active { display: flex; }
        .staffapp-topbar { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: #151820; border-bottom: 1px solid #252a38; }
        .staffapp-title { font-family: 'Bebas Neue', sans-serif; font-size: 22px; color: #60a5fa; }
        .staffapp-role { font-size: 11px; color: #6b7280; text-transform: uppercase; }
        .staffapp-btn-icon { width: 38px; height: 38px; border-radius: 10px; border: 1px solid #252a38; background: #1c2030; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .staffapp-btn-icon svg { width: 20px; height: 20px; stroke: #e8eaf0; stroke-width: 1.5; }
        .staffapp-card { background: #151820; border: 1px solid #252a38; border-radius: 14px; padding: 20px; margin-bottom: 16px; }
        .staffapp-card-title { font-size: 13px; font-weight: 700; text-transform: uppercase; color: #6b7280; margin-bottom: 16px; }
        .staffapp-form-input, .staffapp-login-input { width: 100%; padding: 14px; border-radius: 10px; border: 1px solid #252a38; background: #1c2030; color: #e8eaf0; font-size: 15px; outline: none; margin-bottom: 12px; }
        .staffapp-btn { padding: 12px 20px; border-radius: 10px; border: none; font-weight: 700; cursor: pointer; transition: opacity 0.2s; }
        .staffapp-btn:active { opacity: 0.8; }
        .staffapp-btn-blue { background: #3b82f6; color: #fff; }
        .staffapp-btn-green { background: #22c55e; color: #fff; }
        .staffapp-btn-red { background: #ef4444; color: #fff; }
        .staffapp-btn-orange { background: #f59e0b; color: #fff; }
        .staffapp-btn-gray { background: #4b5563; color: #fff; }
        .staffapp-camera-wrap { position: relative; width: 100%; max-width: 400px; margin: 0 auto; border-radius: 14px; overflow: hidden; background: #000; aspect-ratio: 4/3; }
        .staffapp-video { width: 100%; height: 100%; object-fit: cover; }
        .staffapp-photo-strip { display: flex; gap: 8px; flex-wrap: wrap; margin: 12px 0; }
        .staffapp-photo-thumb { width: 70px; height: 70px; border-radius: 10px; object-fit: cover; border: 2px solid #252a38; cursor: pointer; }
        .staffapp-photo-thumb.main { border-color: #3b82f6; }
        .staffapp-emp-list { display: flex; flex-direction: column; gap: 10px; }
        .staffapp-emp-card { display: flex; align-items: center; gap: 14px; background: #1c2030; border: 1px solid #252a38; border-radius: 14px; padding: 12px; transition: all 0.2s; }
        .staffapp-emp-card.fired { opacity: 0.6; border-color: #ef4444; }
        .staffapp-emp-avatar { width: 52px; height: 52px; border-radius: 10px; object-fit: cover; flex-shrink: 0; }
        .staffapp-emp-info { flex: 1; cursor: pointer; }
        .staffapp-emp-name { font-size: 14px; font-weight: 700; }
        .staffapp-emp-name:hover { color: #60a5fa; }
        .staffapp-emp-pos { font-size: 12px; color: #6b7280; }
        .staffapp-emp-date { font-size: 11px; color: #6b7280; margin-top: 2px; }
        .staffapp-status-badge { display: inline-block; font-size: 10px; padding: 2px 6px; border-radius: 4px; margin-left: 8px; }
        .staffapp-status-active { background: rgba(34,197,94,0.15); color: #22c55e; }
        .staffapp-status-fired { background: rgba(239,68,68,0.15); color: #ef4444; }
        .staffapp-nav-tabs { display: flex; background: #151820; border-bottom: 1px solid #252a38; overflow-x: auto; }
        .staffapp-nav-tab { padding: 12px 18px; font-size: 13px; font-weight: 600; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; white-space: nowrap; }
        .staffapp-nav-tab.active { color: #60a5fa; border-bottom-color: #3b82f6; }
        .staffapp-tab-panel { display: none; padding: 20px; }
        .staffapp-tab-panel.active { display: block; }
        .staffapp-att-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .staffapp-att-table th, .staffapp-att-table td { padding: 10px; text-align: left; border-bottom: 1px solid #252a38; }
        .staffapp-time-in { background: rgba(34,197,94,0.15); color: #22c55e; padding: 3px 8px; border-radius: 6px; }
        .staffapp-time-out { background: rgba(239,68,68,0.15); color: #ef4444; padding: 3px 8px; border-radius: 6px; }
        .staffapp-guard-result { margin: 16px 20px 0; padding: 16px; border-radius: 14px; border: 2px solid #252a38; display: none; align-items: center; gap: 14px; }
        .staffapp-guard-result.show { display: flex; }
        .staffapp-guard-result.found { border-color: #22c55e; background: rgba(34,197,94,0.08); }
        .staffapp-guard-result.fired { border-color: #ef4444; background: rgba(239,68,68,0.08); }
        .staffapp-guard-result.unknown { border-color: #f59e0b; background: rgba(245,158,11,0.08); }
        .staffapp-guard-avatar { width: 64px; height: 64px; border-radius: 12px; object-fit: cover; }
        .staffapp-guard-name { font-size: 16px; font-weight: 700; }
        .staffapp-guard-actions { display: flex; gap: 10px; margin: 12px 20px; }
        .staffapp-guard-actions .staffapp-btn { flex: 1; padding: 14px; }
        .staffapp-login-box { max-width: 360px; margin: 100px auto; background: #151820; border: 1px solid #252a38; border-radius: 20px; padding: 36px 28px; text-align: center; }
        .staffapp-login-logo { font-family: 'Bebas Neue', sans-serif; font-size: 42px; color: #60a5fa; }
        .staffapp-role-tabs { display: flex; gap: 8px; margin-bottom: 24px; }
        .staffapp-role-tab { flex: 1; padding: 10px; border-radius: 10px; border: 1px solid #252a38; background: transparent; color: #6b7280; cursor: pointer; }
        .staffapp-role-tab.active { background: #3b82f6; border-color: #3b82f6; color: #fff; }
        .staffapp-empty { text-align: center; color: #6b7280; padding: 40px; }
        .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); background: #1c2030; border: 1px solid #252a38; padding: 12px 20px; border-radius: 30px; font-size: 14px; z-index: 1000; }
        .staffapp-button-group { display: flex; gap: 8px; flex-wrap: wrap; }
        .staffapp-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 1000; justify-content: center; align-items: center; overflow-y: auto; }
        .staffapp-modal.active { display: flex; }
        .staffapp-modal-content { background: #151820; border-radius: 20px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; padding: 20px; position: relative; }
        .staffapp-modal-close { position: absolute; top: 15px; right: 15px; background: #ef4444; border: none; border-radius: 50%; width: 32px; height: 32px; color: white; font-size: 18px; cursor: pointer; }
        .staffapp-photo-gallery { display: flex; gap: 10px; flex-wrap: wrap; margin: 16px 0; justify-content: center; }
        .staffapp-gallery-img { width: 100px; height: 100px; border-radius: 12px; object-fit: cover; cursor: pointer; border: 2px solid #252a38; }
        .staffapp-history-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #252a38; }
        .staffapp-modal-buttons { display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap; }
        .staffapp-guard-table { width: 100%; border-collapse: collapse; }
        .staffapp-guard-table th, .staffapp-guard-table td { padding: 10px; text-align: left; border-bottom: 1px solid #252a38; }
        .staffapp-guard-edit-row { display: flex; gap: 8px; align-items: center; }
        .staffapp-guard-edit-row input { flex: 1; padding: 8px; border-radius: 8px; border: 1px solid #252a38; background: #1c2030; color: #e8eaf0; }
        .staffapp-debug { margin: 12px 0; padding: 12px 16px; background: #1a0000; border: 1px solid #ef4444; border-radius: 10px; color: #fca5a5; font-size: 12px; font-family: monospace; display: none; white-space: pre-wrap; word-break: break-all; }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.21.0/dist/tf.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <script>
    const API_URL = '<?php echo get_rest_url(null, 'staffapp/v1'); ?>';
    const PHOTO_URL = '<?php echo wp_upload_dir()['baseurl'] . '/staffapp_photos/'; ?>';
    let currentRole = 'manager';
    let currentGuardName = '';
    let recognizedEmployee = null;
    let capturedPhotos = [];
    let faceApiReady = false;
    let currentStream = null;
    let allEmployees = [];
    let allGuards = [];

    // Поріг розпізнавання (0.45 = чутливіший, 0.6 = норма)
    const FACE_MATCH_THRESHOLD = 0.55;

    function toast(msg, isError = false) {
        let t = document.querySelector('.toast');
        if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
        t.textContent = msg;
        t.style.background = isError ? '#fee2e2' : '#1c2030';
        t.style.color = isError ? '#991b1b' : '#e8eaf0';
        t.style.borderColor = isError ? '#ef4444' : '#3b82f6';
        t.style.display = 'block';
        clearTimeout(t._timer);
        t._timer = setTimeout(() => t.style.display = 'none', 3000);
    }

    function debugLog(msg) {
        const el = document.getElementById('staffapp-debug');
        if (!el) return;
        el.style.display = 'block';
        el.textContent += new Date().toTimeString().slice(0,8) + ' ' + msg + '\n';
        console.log(msg);
    }

    async function loadFaceApi() {
        toast('Завантаження системи розпізнавання...');
        try {
            // Використовуємо стабільний CDN з моделями
            const MODEL_URL = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/models';
            await Promise.all([
                faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
                faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
                faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
            ]);
            faceApiReady = true;
            toast('✅ Система готова до роботи');
            debugLog('FaceAPI models loaded, backend: ' + tf.getBackend());
        } catch(e) {
            console.error('Помилка завантаження моделей:', e);
            toast('⚠️ Помилка завантаження: ' + e.message, true);
            debugLog('ERROR: ' + e.message);
            faceApiReady = false;
        }
    }

    function showLogin() {
        document.getElementById('loginScreen').classList.add('active');
        document.getElementById('managerScreen')?.classList.remove('active');
        document.getElementById('guardScreen')?.classList.remove('active');
        if (currentStream) { currentStream.getTracks().forEach(t => t.stop()); currentStream = null; }
    }

    function selectRole(role) {
        currentRole = role;
        document.querySelectorAll('.staffapp-role-tab').forEach((t, i) => {
            t.classList.toggle('active', (i === 0 && role === 'manager') || (i === 1 && role === 'guard'));
        });
    }

    async function doLogin() {
        const pwd = document.getElementById('loginPassword').value;
        const res = await fetch(API_URL + '/login', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ role: currentRole, password: pwd })
        });
        const data = await res.json();
        if (data.success) {
            if (data.role === 'manager') { showManagerScreen(); }
            else { currentGuardName = data.name; showGuardScreen(); startGuardCamera(); renderGuardLog(); }
        } else { toast('Невірний пароль'); }
    }

    function showManagerScreen() {
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('managerScreen').classList.add('active');
        renderEmployees(); renderAttendance(); renderStats(); renderGuards();
        startAddCamera();
    }

    function showGuardScreen() {
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('guardScreen').classList.add('active');
        document.getElementById('guardNameTop').textContent = currentGuardName;
    }

    function showTab(tabId) {
        document.querySelectorAll('.staffapp-tab-panel').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.staffapp-nav-tab').forEach(t => t.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        event.currentTarget.classList.add('active');
        if (tabId === 'tabAdd') startAddCamera();
        if (tabId === 'tabEmployees') renderEmployees();
        if (tabId === 'tabAttendance') renderAttendance();
        if (tabId === 'tabStats') renderStats();
        if (tabId === 'tabGuards') renderGuards();
    }

    async function startAddCamera() {
        if (currentStream) currentStream.getTracks().forEach(t => t.stop());
        try {
            currentStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
            document.getElementById('addVideo').srcObject = currentStream;
            debugLog('Камера додавання запущена');
        } catch(e) { toast('Камера недоступна: ' + e.message); debugLog('Camera error: ' + e.message); }
    }

    async function startGuardCamera() {
        if (currentStream) currentStream.getTracks().forEach(t => t.stop());
        try {
            currentStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
            document.getElementById('guardVideo').srcObject = currentStream;
            debugLog('Камера охоронця запущена');
        } catch(e) { toast('Камера недоступна'); debugLog('Guard camera error: ' + e.message); }
    }

    function capturePhoto() {
        if (capturedPhotos.length >= 5) { toast('Максимум 5 фото'); return; }
        const video = document.getElementById('addVideo');
        if (!video || !video.videoWidth || video.videoWidth === 0) {
            toast('Камера не готова, зачекайте');
            return;
        }
        const canvas = document.getElementById('addCanvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        capturedPhotos.push(dataUrl);
        renderPhotoStrip();
        toast(`Фото ${capturedPhotos.length}/5 додано`);
    }

    function renderPhotoStrip() {
        const strip = document.getElementById('photoStrip');
        strip.innerHTML = capturedPhotos.map((p, i) => `<img src="${p}" class="staffapp-photo-thumb ${i===0?'main':''}">`).join('');
    }

    function clearPhotos() { capturedPhotos = []; renderPhotoStrip(); }

    async function saveEmployee() {
        const pib = document.getElementById('empPib').value.trim();
        const posada = document.getElementById('empPosada').value.trim();
        const dateIn = document.getElementById('empDateIn').value;
        
        if (!pib || !posada) { toast('Заповніть ПІБ та посаду'); return; }
        if (!dateIn) { toast('Вкажіть дату прийняття'); return; }
        if (capturedPhotos.length === 0) { toast('Зробіть фото'); return; }

        const btn = document.querySelector('[onclick="saveEmployee()"]');
        if (btn) { btn.disabled = true; btn.textContent = '⏳ Збереження...'; }

        let descriptors = [];
        let photoFilenames = [];
        const tempId = Date.now().toString();

        toast('Завантаження фото...');
        for (let i = 0; i < capturedPhotos.length; i++) {
            try {
                const res = await fetch(API_URL + '/upload_photo', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ photo: capturedPhotos[i], employee_id: tempId + '_' + i })
                });
                const data = await res.json();
                if (data.success) photoFilenames.push(data.filename);
                else debugLog('upload_photo fail: ' + JSON.stringify(data));
            } catch(e) {
                debugLog('Fetch upload_photo: ' + e.message);
                toast('Помилка мережі: ' + e.message, true);
                if (btn) { btn.disabled = false; btn.textContent = '➕ Додати працівника'; }
                return;
            }
        }

        if (photoFilenames.length === 0) {
            toast('Фото не завантажено', true);
            if (btn) { btn.disabled = false; btn.textContent = '➕ Додати працівника'; }
            return;
        }

        if (faceApiReady) {
            toast('Аналіз облич...');
            for (const photo of capturedPhotos) {
                try {
                    const img = await new Promise((res, rej) => {
                        const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = photo;
                    });
                    const det = await faceapi.detectSingleFace(img, new faceapi.TinyFaceDetectorOptions())
                        .withFaceLandmarks().withFaceDescriptor();
                    if (det) {
                        descriptors.push(Array.from(det.descriptor));
                        debugLog('Дескриптор отримано');
                    }
                } catch(e) {
                    debugLog('detectSingleFace: ' + e.message);
                }
            }
        }

        try {
            const res = await fetch(API_URL + '/employee', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    pib, posada, date_in: dateIn,
                    main_photo: photoFilenames[0] || '',
                    photos: photoFilenames,
                    descriptors: descriptors
                })
            });
            const data = await res.json();
            if (data.success) {
                toast('✅ ' + pib + ' додано!');
                document.getElementById('empPib').value = '';
                document.getElementById('empPosada').value = '';
                document.getElementById('empDateIn').value = new Date().toISOString().slice(0,10);
                capturedPhotos = [];
                renderPhotoStrip();
                renderEmployees();
                if (descriptors.length === 0) {
                    setTimeout(() => toast('⚠️ Обличчя не розпізнано — зробіть нові фото при кращому освітленні'), 2000);
                }
            } else {
                toast('Помилка: ' + (data.error || 'невідома'), true);
                debugLog('Save error: ' + JSON.stringify(data));
            }
        } catch(e) {
            debugLog('Fetch /employee: ' + e.message);
            toast('Помилка мережі: ' + e.message, true);
        }

        if (btn) { btn.disabled = false; btn.textContent = '➕ Додати працівника'; }
    }

    async function fireEmployee(id, pib) {
        if (!confirm(`Звільнити ${pib}?`)) return;
        await fetch(API_URL + '/fire', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        toast(`${pib} звільнено`);
        renderEmployees();
    }

    async function restoreEmployee(id, pib) {
        if (!confirm(`Відновити ${pib}?`)) return;
        await fetch(API_URL + '/restore', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        toast(`${pib} відновлено`);
        renderEmployees();
    }

    async function deleteEmployee(id, pib) {
        if (!confirm(`Видалити ${pib} назавжди? Цю дію не можна скасувати.`)) return;
        await fetch(API_URL + '/delete', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        toast(`${pib} видалено з бази`);
        renderEmployees();
    }

    async function showEmployeeCard(employee) {
        const modal = document.getElementById('employeeModal');
        const content = document.getElementById('modalContent');
        const historyRes = await fetch(API_URL + `/attendance/by_employee?emp_id=${employee.id}`);
        const history = await historyRes.json();
        const photos = employee.photos || [];
        const isFired = employee.fired == 1;
        
        let historyHtml = '';
        if (history.length === 0) {
            historyHtml = '<div style="text-align:center;padding:20px;color:#6b7280">Немає записів</div>';
        } else {
            historyHtml = history.map(h => `
                <div class="staffapp-history-item">
                    <span>${h.date}</span>
                    <span>${h.time}</span>
                    <span class="${h.type === 'in' ? 'staffapp-time-in' : 'staffapp-time-out'}">${h.type === 'in' ? 'Прийшов' : 'Пішов'}</span>
                    <span style="font-size:11px;color:#6b7280">${h.guard_name || ''}</span>
                </div>
            `).join('');
        }
        
        content.innerHTML = `
            <div><div class="staffapp-card-title">📸 Фотографії</div>
            <div class="staffapp-photo-gallery">${photos.map(p => `<img src="${p.startsWith('http') ? p : PHOTO_URL + p}" class="staffapp-gallery-img" onclick="viewImage('${p.startsWith('http') ? p : PHOTO_URL + p}')">`).join('')}</div></div>
            <div><div class="staffapp-card-title">👤 Інформація</div>
            <div><strong>ПІБ:</strong> ${employee.pib}</div>
            <div><strong>Посада:</strong> ${employee.posada}</div>
            <div><strong>Дата прийняття:</strong> ${employee.date_in || '—'}</div>
            ${isFired ? `<div><strong>Дата звільнення:</strong> ${employee.date_out || '—'}</div><div style="color:#ef4444;margin-top:8px">⚠️ СТАТУС: ЗВІЛЬНЕНИЙ</div>` : `<div style="color:#22c55e;margin-top:8px">✅ СТАТУС: ПРАЦЮЄ</div>`}
            </div>
            <div><div class="staffapp-card-title">📋 Історія відміток</div>
            <div style="max-height:300px;overflow-y:auto">${historyHtml}</div></div>
            <div class="staffapp-modal-buttons">
                ${!isFired ? 
                    `<button class="staffapp-btn staffapp-btn-red" onclick="fireEmployee(${employee.id}, '${employee.pib}'); closeModal()">🔴 Звільнити</button>` : 
                    `<button class="staffapp-btn staffapp-btn-green" onclick="restoreEmployee(${employee.id}, '${employee.pib}'); closeModal()">🟢 Відновити</button>`
                }
                <button class="staffapp-btn staffapp-btn-orange" onclick="deleteEmployee(${employee.id}, '${employee.pib}'); closeModal()">🗑 Видалити</button>
                <button class="staffapp-btn staffapp-btn-gray" onclick="closeModal()">Закрити</button>
            </div>
        `;
        modal.classList.add('active');
        window.currentEmployee = employee;
    }

    function viewImage(src) {
        const modal = document.getElementById('employeeModal');
        const content = document.getElementById('modalContent');
        content.innerHTML = `
            <img src="${src}" style="width:100%;max-height:80vh;object-fit:contain;border-radius:12px">
            <button class="staffapp-btn staffapp-btn-gray" style="margin-top:20px;width:100%" onclick="showEmployeeCard(window.currentEmployee)">Назад</button>
        `;
    }

    function closeModal() {
        document.getElementById('employeeModal').classList.remove('active');
    }

    async function renderEmployees() {
        const res = await fetch(API_URL + '/employees');
        allEmployees = await res.json();
        const list = document.getElementById('empList');
        if (!allEmployees.length) { list.innerHTML = '<div class="staffapp-empty">Немає працівників</div>'; return; }
        list.innerHTML = allEmployees.map(e => {
            const isFired = e.fired == 1;
            const avatarUrl = e.main_photo && e.main_photo.startsWith('http') ? e.main_photo : (e.main_photo ? PHOTO_URL + e.main_photo : '');
            return `
                <div class="staffapp-emp-card ${isFired ? 'fired' : ''}">
                    <img class="staffapp-emp-avatar" src="${avatarUrl}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'52\' height=\'52\'%3E%3Crect fill=\'%231c2030\' width=\'52\' height=\'52\'/%3E%3Ctext x=\'26\' y=\'33\' font-size=\'22\' text-anchor=\'middle\' fill=\'%236b7280\'%3E${e.pib.charAt(0)}%3C/text%3E%3C/svg%3E'">
                    <div class="staffapp-emp-info" onclick="showEmployeeCard(${JSON.stringify(e).replace(/"/g, '&quot;')})">
                        <div class="staffapp-emp-name">
                            ${e.pib}
                            <span class="staffapp-status-badge ${isFired ? 'staffapp-status-fired' : 'staffapp-status-active'}">${isFired ? 'Звільнений' : 'Працює'}</span>
                        </div>
                        <div class="staffapp-emp-pos">${e.posada}</div>
                        <div class="staffapp-emp-date">📅 з ${e.date_in || '—'}${e.date_out ? ' | зв. ' + e.date_out : ''}</div>
                    </div>
                    <div class="staffapp-button-group" onclick="event.stopPropagation()">
                        ${!isFired ? 
                            `<button class="staffapp-btn staffapp-btn-red" style="padding:6px 12px;font-size:12px" onclick="fireEmployee(${e.id}, '${e.pib}')">🔴 Звільнити</button>` :
                            `<button class="staffapp-btn staffapp-btn-green" style="padding:6px 12px;font-size:12px" onclick="restoreEmployee(${e.id}, '${e.pib}')">🟢 Відновити</button>`
                        }
                        <button class="staffapp-btn staffapp-btn-orange" style="padding:6px 12px;font-size:12px" onclick="deleteEmployee(${e.id}, '${e.pib}')">🗑 Видалити</button>
                    </div>
                </div>
            `;
        }).join('');
    }

    async function renderAttendance() {
        const date = document.getElementById('attDate').value || new Date().toISOString().slice(0,10);
        const res = await fetch(API_URL + `/attendance?date=${date}`);
        const att = await res.json();
        const tbody = document.getElementById('attTbody');
        if (!att.length) { tbody.innerHTML = '<tr><td colspan="3" class="staffapp-empty">Немає записів</td></table>'; return; }
        tbody.innerHTML = att.map(a => `<tr><td style="padding:8px">${a.emp_name}</td><td style="padding:8px">${a.time}</td><td style="padding:8px"><span class="staffapp-${a.type === 'in' ? 'time-in' : 'time-out'}">${a.type === 'in' ? 'Прийшов' : 'Пішов'}</span></td></tr>`).join('');
    }

    async function renderStats() {
        const date = document.getElementById('statsDate').value || new Date().toISOString().slice(0,10);
        const res = await fetch(API_URL + `/attendance?date=${date}`);
        const att = await res.json();
        const unique = [...new Set(att.filter(a => a.type === 'in').map(a => a.emp_name))];
        document.getElementById('statsCount').innerHTML = `<div class="staffapp-card" style="text-align:center"><div style="font-size:48px;font-weight:700;color:#60a5fa">${unique.length}</div><div>прийшло на роботу</div></div>`;
    }

    async function renderGuards() {
        const res = await fetch(API_URL + '/guards');
        allGuards = await res.json();
        const container = document.getElementById('guardsList');
        if (!allGuards.length) { container.innerHTML = '<div class="staffapp-empty">Немає охоронців</div>'; return; }
        
        container.innerHTML = `
            <table class="staffapp-guard-table">
                <thead><tr><th>ПІБ</th><th>Дата додавання</th><th>Дії</th></tr></thead>
                <tbody>
                    ${allGuards.map(g => `
                        <tr id="guard-row-${g.id}">
                            <td>${g.name}</td>
                            <td>${g.created_at ? g.created_at.split(' ')[0] : '—'}</td>
                            <td>
                                <div class="staffapp-guard-edit-row" id="guard-edit-${g.id}" style="display:none">
                                    <input type="password" id="guard-new-pwd-${g.id}" placeholder="Новий пароль">
                                    <button class="staffapp-btn staffapp-btn-green" style="padding:4px 8px;font-size:11px" onclick="updateGuard(${g.id})">Зберегти</button>
                                    <button class="staffapp-btn staffapp-btn-gray" style="padding:4px 8px;font-size:11px" onclick="cancelEditGuard(${g.id})">Скасувати</button>
                                </div>
                                <div id="guard-btns-${g.id}">
                                    <button class="staffapp-btn staffapp-btn-blue" style="padding:4px 12px;font-size:11px" onclick="showGuardEdit(${g.id})">Змінити пароль</button>
                                    <button class="staffapp-btn staffapp-btn-red" style="padding:4px 12px;font-size:11px" onclick="deleteGuard(${g.id}, '${g.name}')">Видалити</button>
                                </div>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    function showGuardEdit(id) {
        document.getElementById(`guard-edit-${id}`).style.display = 'flex';
        document.getElementById(`guard-btns-${id}`).style.display = 'none';
    }

    function cancelEditGuard(id) {
        document.getElementById(`guard-edit-${id}`).style.display = 'none';
        document.getElementById(`guard-btns-${id}`).style.display = 'flex';
    }

    async function updateGuard(id) {
        const newPwd = document.getElementById(`guard-new-pwd-${id}`).value;
        if (!newPwd) { toast('Введіть новий пароль'); return; }
        const res = await fetch(API_URL + '/guard/update', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id, password: newPwd })
        });
        const data = await res.json();
        if (data.success) {
            toast('Пароль змінено');
            cancelEditGuard(id);
        } else { toast('Помилка'); }
    }

    async function deleteGuard(id, name) {
        if (!confirm(`Видалити охоронця ${name}?`)) return;
        const res = await fetch(API_URL + '/guard/delete', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await res.json();
        if (data.success) {
            toast(`Охоронця ${name} видалено`);
            renderGuards();
        } else { toast('Помилка'); }
    }

    async function addGuard() {
        const name = document.getElementById('newGuardName').value.trim();
        const pwd = document.getElementById('newGuardPwd').value;
        if (!name || !pwd) { toast('Введіть ім\'я та пароль'); return; }
        const res = await fetch(API_URL + '/guard', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: name, password: pwd })
        });
        const data = await res.json();
        if (data.success) {
            toast(`Охоронця ${name} додано`);
            document.getElementById('newGuardName').value = '';
            document.getElementById('newGuardPwd').value = '';
            renderGuards();
        } else { toast('Помилка'); }
    }

    function exportEmployees() { window.location.href = API_URL + '/export/employees'; }
    function exportAttendance() { window.location.href = API_URL + '/export/attendance?date=' + document.getElementById('attDate').value; }

    async function scanFace() {
        if (!faceApiReady) { toast('Зачекайте, завантаження моделей...'); return; }
        const btn = document.getElementById('scanBtn');
        btn.disabled = true; btn.textContent = '⏳ Розпізнаю...';
        debugLog('Початок розпізнавання');
        
        const video = document.getElementById('guardVideo');
        const canvas = document.getElementById('guardCanvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        
        try {
            const detection = await faceapi.detectSingleFace(canvas, new faceapi.TinyFaceDetectorOptions())
                .withFaceLandmarks().withFaceDescriptor();
            if (!detection) { 
                toast('Обличчя не знайдено'); 
                debugLog('Обличчя не знайдено');
                btn.disabled = false; btn.textContent = '🔍 Розпізнати'; 
                return; 
            }
            debugLog('Обличчя знайдено, шукаємо збіг...');
            
            const res = await fetch(API_URL + '/employees');
            const employees = await res.json();
            let bestMatch = null, bestDist = FACE_MATCH_THRESHOLD;
            for (const emp of employees) {
                if (!emp.descriptors || !emp.descriptors.length) continue;
                for (const desc of emp.descriptors) {
                    const dist = faceapi.euclideanDistance(detection.descriptor, new Float32Array(desc));
                    if (dist < bestDist) { 
                        bestDist = dist; 
                        bestMatch = emp; 
                        debugLog(`Збіг: ${emp.pib} відстань=${dist.toFixed(3)}`);
                    }
                }
            }
            
            if (bestMatch) {
                recognizedEmployee = bestMatch;
                const rdiv = document.getElementById('guardResult');
                const avatarUrl = bestMatch.main_photo && bestMatch.main_photo.startsWith('http') ? bestMatch.main_photo : (bestMatch.main_photo ? PHOTO_URL + bestMatch.main_photo : '');
                document.getElementById('guardResultImg').src = avatarUrl;
                document.getElementById('guardResultName').innerHTML = bestMatch.pib + '<br><small>' + bestMatch.posada + '</small>';
                if (bestMatch.fired) {
                    rdiv.className = 'staffapp-guard-result show fired';
                    document.getElementById('guardActions').style.display = 'none';
                    toast('Звільнений');
                } else {
                    rdiv.className = 'staffapp-guard-result show found';
                    document.getElementById('guardActions').style.display = 'flex';
                    toast(`Знайдено: ${bestMatch.pib}`);
                }
            } else {
                document.getElementById('guardResult').className = 'staffapp-guard-result show unknown';
                document.getElementById('guardResultName').innerHTML = 'Невідома особа';
                document.getElementById('guardActions').style.display = 'none';
                toast('Невідома особа');
                debugLog('Збігів не знайдено');
            }
        } catch(e) {
            console.error(e);
            toast('Помилка розпізнавання');
            debugLog('Scan error: ' + e.message);
        }
        btn.disabled = false; btn.textContent = '🔍 Розпізнати';
    }

    async function markAttendance(type) {
        if (!recognizedEmployee || recognizedEmployee.fired) return;
        await fetch(API_URL + '/attendance', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ emp_id: recognizedEmployee.id, emp_name: recognizedEmployee.pib, type: type, guard_name: currentGuardName })
        });
        toast(type === 'in' ? `✅ ${recognizedEmployee.pib} прийшов` : `🚪 ${recognizedEmployee.pib} пішов`);
        renderGuardLog();
    }

    async function renderGuardLog() {
        const date = new Date().toISOString().slice(0,10);
        const res = await fetch(API_URL + `/attendance?date=${date}`);
        const att = await res.json();
        const log = document.getElementById('guardLog');
        if (!att.length) { log.innerHTML = '<div class="staffapp-empty">Немає записів</div>'; return; }
        log.innerHTML = att.slice(0,10).map(a => `<div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #252a38"><span>${a.emp_name}</span><span>${a.time}</span><span class="staffapp-${a.type === 'in' ? 'time-in' : 'time-out'}">${a.type === 'in' ? '↑' : '↓'}</span></div>`).join('');
    }

    function logout() {
        if (currentStream) { currentStream.getTracks().forEach(t => t.stop()); currentStream = null; }
        showLogin();
    }

    window.addEventListener('DOMContentLoaded', async () => {
        await loadFaceApi();
        const today = new Date().toISOString().slice(0,10);
        document.getElementById('staffapp-root').innerHTML = `
            <div id="loginScreen" class="staffapp-screen active">
                <div class="staffapp-login-box"><div class="staffapp-login-logo">ПРОХІДНА</div><div class="staffapp-login-sub">Система обліку персоналу</div>
                <div class="staffapp-role-tabs"><button class="staffapp-role-tab active" onclick="selectRole('manager')">Керівник</button><button class="staffapp-role-tab" onclick="selectRole('guard')">Охоронець</button></div>
                <input type="password" id="loginPassword" class="staffapp-login-input" placeholder="Пароль" onkeydown="if(event.key==='Enter')doLogin()">
                <button class="staffapp-btn staffapp-btn-blue" onclick="doLogin()">Увійти</button></div>
            </div>
            <div id="managerScreen" class="staffapp-screen">
                <div class="staffapp-topbar"><div><div class="staffapp-title">ПРОХІДНА</div><div class="staffapp-role">Керівник</div></div><div class="staffapp-btn-icon" onclick="logout()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg></div></div>
                <div class="staffapp-nav-tabs"><div class="staffapp-nav-tab active" onclick="showTab('tabAdd')">➕ Додати</div><div class="staffapp-nav-tab" onclick="showTab('tabEmployees')">👥 Працівники</div><div class="staffapp-nav-tab" onclick="showTab('tabAttendance')">📋 Журнал</div><div class="staffapp-nav-tab" onclick="showTab('tabStats')">📊 Зведення</div><div class="staffapp-nav-tab" onclick="showTab('tabGuards')">🔐 Охоронці</div></div>
                <div id="tabAdd" class="staffapp-tab-panel active">
                    <div class="staffapp-card"><div class="staffapp-card-title">Новий працівник</div>
                        <input id="empPib" class="staffapp-form-input" placeholder="ПІБ">
                        <input id="empPosada" class="staffapp-form-input" placeholder="Посада">
                        <label style="font-size:12px;color:#6b7280;margin-bottom:4px;display:block">📅 Дата прийняття</label>
                        <input id="empDateIn" class="staffapp-form-input" type="date" value="${today}"></div>
                    <div class="staffapp-card"><div class="staffapp-card-title">Фото працівника (до 5)</div>
                        <div class="staffapp-camera-wrap"><video id="addVideo" class="staffapp-video" autoplay muted playsinline></video></div>
                        <canvas id="addCanvas" style="display:none"></canvas><div id="photoStrip" class="staffapp-photo-strip"></div>
                        <div style="display:flex;gap:10px"><button class="staffapp-btn staffapp-btn-blue" onclick="capturePhoto()">📷 Зробити фото</button><button class="staffapp-btn" style="background:#1c2030" onclick="clearPhotos()">🗑 Очистити</button></div>
                        <div style="font-size:11px;color:#6b7280;margin-top:8px">📌 Перше фото буде головним</div>
                    </div>
                    <button class="staffapp-btn staffapp-btn-green" onclick="saveEmployee()">➕ Додати працівника</button>
                    <div id="staffapp-debug" class="staffapp-debug"></div>
                </div>
                <div id="tabEmployees" class="staffapp-tab-panel">
                    <div style="display:flex;justify-content:space-between;margin-bottom:16px"><div class="staffapp-card-title">Список працівників</div><button class="staffapp-btn staffapp-btn-blue" style="width:auto;padding:8px 16px" onclick="exportEmployees()">📎 Скачати Excel</button></div>
                    <div id="empList"></div>
                </div>
                <div id="tabAttendance" class="staffapp-tab-panel">
                    <div style="display:flex;gap:10px;margin-bottom:16px"><input id="attDate" class="staffapp-form-input" type="date" value="${today}" onchange="renderAttendance()" style="margin-bottom:0"><button class="staffapp-btn staffapp-btn-blue" style="width:auto" onclick="exportAttendance()">📎 Скачати Excel</button></div>
                    <table class="staffapp-att-table"><thead><tr><th>ПІБ</th><th>Час</th><th>Подія</th></tr></thead><tbody id="attTbody"></tbody></table>
                </div>
                <div id="tabStats" class="staffapp-tab-panel"><input id="statsDate" class="staffapp-form-input" type="date" value="${today}" onchange="renderStats()"><div id="statsCount" style="margin-top:16px"></div></div>
                <div id="tabGuards" class="staffapp-tab-panel">
                    <div class="staffapp-card"><div class="staffapp-card-title">Додати охоронця</div>
                        <div style="display:flex;gap:10px;flex-wrap:wrap"><input id="newGuardName" class="staffapp-form-input" placeholder="ПІБ охоронця" style="flex:1;margin-bottom:0"><input id="newGuardPwd" class="staffapp-form-input" type="password" placeholder="Пароль" style="width:120px;margin-bottom:0"><button class="staffapp-btn staffapp-btn-green" onclick="addGuard()">➕ Додати</button></div>
                    </div>
                    <div class="staffapp-card"><div class="staffapp-card-title">Список охоронців</div><div id="guardsList"></div></div>
                </div>
            </div>
            <div id="guardScreen" class="staffapp-screen">
                <div class="staffapp-topbar"><div><div class="staffapp-title">ПРОХІДНА</div><div class="staffapp-role" id="guardNameTop">Охоронець</div></div><div class="staffapp-btn-icon" onclick="logout()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg></div></div>
                <div style="padding:16px 20px"><div class="staffapp-camera-wrap"><video id="guardVideo" class="staffapp-video" autoplay muted playsinline></video></div><canvas id="guardCanvas" style="display:none"></canvas><button id="scanBtn" class="staffapp-btn staffapp-btn-blue" style="width:100%;margin-top:12px" onclick="scanFace()">🔍 Розпізнати обличчя</button></div>
                <div id="guardResult" class="staffapp-guard-result"><img id="guardResultImg" class="staffapp-guard-avatar"><div id="guardResultName"></div></div>
                <div id="guardActions" class="staffapp-guard-actions" style="display:none"><button class="staffapp-btn staffapp-btn-green" onclick="markAttendance('in')">✅ Прийшов</button><button class="staffapp-btn staffapp-btn-red" onclick="markAttendance('out')">🚪 Пішов</button></div>
                <div class="staffapp-card" style="margin:0 20px"><div class="staffapp-card-title">Сьогоднішній журнал</div><div id="guardLog"></div></div>
            </div>
            <div id="employeeModal" class="staffapp-modal"><div class="staffapp-modal-content"><button class="staffapp-modal-close" onclick="closeModal()">×</button><div id="modalContent"></div></div></div>
        `;
        showLogin();
    });
    </script>
    <?php
    return ob_get_clean();
}

// ============================================
// АДМІНКА WORDPRESS
// ============================================
add_action('admin_menu', 'staffapp_admin_menu');
function staffapp_admin_menu() {
    add_menu_page('StaffApp', 'StaffApp', 'manage_options', 'staffapp', 'staffapp_admin_page', 'dashicons-id', 30);
}

function staffapp_admin_page() {
    global $wpdb;
    $table_settings = $wpdb->prefix . 'staffapp_settings';
    $table_guards = $wpdb->prefix . 'staffapp_guards';
    
    if (isset($_POST['change_mgr_pwd']) && !empty($_POST['new_mgr_pwd'])) {
        $wpdb->update($table_settings, ['setting_value' => wp_hash_password($_POST['new_mgr_pwd'])], ['setting_key' => 'manager_password']);
        echo '<div class="notice notice-success"><p>✅ Пароль керівника змінено!</p></div>';
    }
    
    if (isset($_POST['add_guard']) && !empty($_POST['guard_name']) && !empty($_POST['guard_pwd'])) {
        $result = $wpdb->insert($table_guards, [
            'name' => sanitize_text_field($_POST['guard_name']),
            'password' => wp_hash_password($_POST['guard_pwd'])
        ]);
        if ($result) {
            echo '<div class="notice notice-success"><p>✅ Охоронця додано!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>❌ Помилка: ' . $wpdb->last_error . '</p></div>';
        }
    }
    
    if (isset($_POST['update_guard']) && !empty($_POST['guard_id']) && !empty($_POST['guard_new_pwd'])) {
        $wpdb->update($table_guards, ['password' => wp_hash_password($_POST['guard_new_pwd'])], ['id' => intval($_POST['guard_id'])]);
        echo '<div class="notice notice-success"><p>✅ Пароль охоронця змінено!</p></div>';
    }
    
    if (isset($_POST['delete_guard']) && !empty($_POST['guard_id'])) {
        $wpdb->delete($table_guards, ['id' => intval($_POST['guard_id'])]);
        echo '<div class="notice notice-success"><p>✅ Охоронця видалено!</p></div>';
    }
    
    $guards = $wpdb->get_results("SELECT * FROM $table_guards ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>StaffApp v3.5</h1>
        <p><a href="<?php echo get_site_url(); ?>/staffapp" target="_blank"><?php echo get_site_url(); ?>/staffapp</a></p>
        <hr>
        
        <h2>🔐 Пароль керівника</h2>
        <form method="post" style="margin-bottom: 30px; display: flex; gap: 10px; align-items: center;">
            <input type="password" name="new_mgr_pwd" placeholder="Новий пароль" required>
            <button type="submit" name="change_mgr_pwd" class="button button-primary">Змінити</button>
        </form>
        
        <hr>
        
        <h2>➕ Додати охоронця</h2>
        <form method="post" style="margin-bottom: 30px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <input type="text" name="guard_name" placeholder="ПІБ охоронця" required style="width: 200px;">
            <input type="password" name="guard_pwd" placeholder="Пароль" required style="width: 150px;">
            <button type="submit" name="add_guard" class="button button-primary">Додати</button>
        </form>
        
        <hr>
        
        <h2>📋 Список охоронців</h2>
        <?php if (empty($guards)): ?>
            <p style="color: #888;">Немає охоронців. Додайте першого вище.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ПІБ</th>
                        <th>Дата додавання</th>
                        <th>Дії</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($guards as $g): ?>
                        <tr>
                            <td><?php echo $g->id; ?></td>
                            <td><strong><?php echo esc_html($g->name); ?></strong></td>
                            <td><?php echo $g->created_at; ?></td>
                            <td>
                                <form method="post" style="display: inline-block; margin-right: 10px;">
                                    <input type="hidden" name="guard_id" value="<?php echo $g->id; ?>">
                                    <input type="password" name="guard_new_pwd" placeholder="Новий пароль" style="width: 120px;">
                                    <button type="submit" name="update_guard" class="button">Змінити пароль</button>
                                </form>
                                <form method="post" style="display: inline-block;" onsubmit="return confirm('Видалити охоронця <?php echo esc_attr($g->name); ?>?')">
                                    <input type="hidden" name="guard_id" value="<?php echo $g->id; ?>">
                                    <button type="submit" name="delete_guard" class="button button-link-delete">🗑 Видалити</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}