<?php
/**
 * Plugin Name: StaffApp
 * Plugin URI: https://your-site.com/staffapp
 * Description: Система обліку персоналу з розпізнаванням облич, журналом приходу/виходу та PWA-режимом.
 * Version: 3.6.0
 * Author: StaffApp
 * License: GPL v2 or later
 * Text Domain: staffapp
 */

if (!defined('ABSPATH')) exit;

define('STAFFAPP_VERSION', '3.6.0');
define('STAFFAPP_FILE', __FILE__);
define('STAFFAPP_DIR', plugin_dir_path(__FILE__));
define('STAFFAPP_URL', plugin_dir_url(__FILE__));

require_once STAFFAPP_DIR . 'includes/class-install.php';
require_once STAFFAPP_DIR . 'includes/class-rest.php';
require_once STAFFAPP_DIR . 'includes/class-admin.php';
require_once STAFFAPP_DIR . 'includes/class-shortcode.php';

register_activation_hook(__FILE__, ['StaffApp_Install', 'activate']);

add_action('plugins_loaded', function () {
    StaffApp_REST::init();
    StaffApp_Admin::init();
    StaffApp_Shortcode::init();
});
