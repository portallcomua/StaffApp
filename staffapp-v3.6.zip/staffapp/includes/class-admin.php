<?php
if (!defined('ABSPATH')) exit;

class StaffApp_Admin {
    public static function init() { add_action('admin_menu', [__CLASS__, 'menu']); }
    public static function menu() { add_menu_page('StaffApp', 'StaffApp', 'manage_options', 'staffapp', [__CLASS__, 'page'], 'dashicons-id', 30); }
    public static function page() {
        global $wpdb;
        $settings = $wpdb->prefix . 'staffapp_settings';
        $guards = $wpdb->prefix . 'staffapp_guards';
        if (isset($_POST['staffapp_nonce']) && wp_verify_nonce($_POST['staffapp_nonce'], 'staffapp_admin')) {
            if (isset($_POST['change_mgr_pwd']) && !empty($_POST['new_mgr_pwd'])) {
                $wpdb->update($settings, ['setting_value' => wp_hash_password((string)$_POST['new_mgr_pwd'])], ['setting_key' => 'manager_password']);
                echo '<div class="notice notice-success"><p>Пароль керівника змінено.</p></div>';
            }
            if (isset($_POST['company_name'])) {
                $name = sanitize_text_field($_POST['company_name']);
                $exists = $wpdb->get_var("SELECT id FROM $settings WHERE setting_key='company_name'");
                if ($exists) $wpdb->update($settings, ['setting_value'=>$name], ['setting_key'=>'company_name']);
                else $wpdb->insert($settings, ['setting_key'=>'company_name','setting_value'=>$name]);
                echo '<div class="notice notice-success"><p>Назву фірми збережено.</p></div>';
            }
            if (isset($_POST['add_guard']) && !empty($_POST['guard_name']) && !empty($_POST['guard_pwd'])) {
                $wpdb->insert($guards, ['name'=>sanitize_text_field($_POST['guard_name']), 'password'=>wp_hash_password((string)$_POST['guard_pwd'])]);
                echo '<div class="notice notice-success"><p>Охоронця додано.</p></div>';
            }
            if (isset($_POST['update_guard']) && !empty($_POST['guard_id']) && !empty($_POST['guard_new_pwd'])) {
                $wpdb->update($guards, ['password'=>wp_hash_password((string)$_POST['guard_new_pwd'])], ['id'=>(int)$_POST['guard_id']]);
                echo '<div class="notice notice-success"><p>Пароль охоронця змінено.</p></div>';
            }
            if (isset($_POST['delete_guard']) && !empty($_POST['guard_id'])) {
                $wpdb->delete($guards, ['id'=>(int)$_POST['guard_id']]);
                echo '<div class="notice notice-success"><p>Охоронця видалено.</p></div>';
            }
        }
        $company = $wpdb->get_var("SELECT setting_value FROM $settings WHERE setting_key='company_name'");
        $items = $wpdb->get_results("SELECT * FROM $guards ORDER BY id DESC");
        ?>
        <div class="wrap"><h1>StaffApp v<?php echo esc_html(STAFFAPP_VERSION); ?></h1>
        <p><a href="<?php echo esc_url(home_url('/staffapp/')); ?>" target="_blank"><?php echo esc_html(home_url('/staffapp/')); ?></a></p>
        <form method="post"><?php wp_nonce_field('staffapp_admin', 'staffapp_nonce'); ?>
            <h2>Налаштування</h2>
            <p><input type="text" name="company_name" value="<?php echo esc_attr($company); ?>" placeholder="Назва фірми" style="width:280px"> <button class="button button-primary">Зберегти</button></p>
        </form>
        <hr><h2>Пароль керівника</h2><form method="post"><?php wp_nonce_field('staffapp_admin', 'staffapp_nonce'); ?><input type="password" name="new_mgr_pwd" placeholder="Новий пароль" required> <button name="change_mgr_pwd" class="button button-primary">Змінити</button></form>
        <hr><h2>Додати охоронця</h2><form method="post"><?php wp_nonce_field('staffapp_admin', 'staffapp_nonce'); ?><input type="text" name="guard_name" placeholder="ПІБ охоронця" required> <input type="password" name="guard_pwd" placeholder="Пароль" required> <button name="add_guard" class="button button-primary">Додати</button></form>
        <hr><h2>Охоронці</h2>
        <table class="widefat striped"><thead><tr><th>ID</th><th>ПІБ</th><th>Дата</th><th>Дії</th></tr></thead><tbody>
        <?php if (!$items): ?><tr><td colspan="4">Немає охоронців.</td></tr><?php endif; ?>
        <?php foreach ($items as $g): ?><tr><td><?php echo (int)$g->id; ?></td><td><strong><?php echo esc_html($g->name); ?></strong></td><td><?php echo esc_html($g->created_at); ?></td><td>
        <form method="post" style="display:inline"><?php wp_nonce_field('staffapp_admin', 'staffapp_nonce'); ?><input type="hidden" name="guard_id" value="<?php echo (int)$g->id; ?>"><input type="password" name="guard_new_pwd" placeholder="Новий пароль"> <button name="update_guard" class="button">Змінити</button></form>
        <form method="post" style="display:inline" onsubmit="return confirm('Видалити охоронця?')"><?php wp_nonce_field('staffapp_admin', 'staffapp_nonce'); ?><input type="hidden" name="guard_id" value="<?php echo (int)$g->id; ?>"><button name="delete_guard" class="button button-link-delete">Видалити</button></form>
        </td></tr><?php endforeach; ?></tbody></table></div><?php
    }
}
