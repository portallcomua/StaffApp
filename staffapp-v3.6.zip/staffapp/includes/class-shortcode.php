<?php
if (!defined('ABSPATH')) exit;

class StaffApp_Shortcode {
    public static function init() {
        add_shortcode('staffapp', [__CLASS__, 'render']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
    }

    public static function assets() {
        if (!is_singular()) return;
        global $post;
        if (!$post || strpos($post->post_content, '[staffapp]') === false) return;
        wp_enqueue_style('staffapp', STAFFAPP_URL . 'assets/css/staffapp.css', [], STAFFAPP_VERSION);
        wp_enqueue_script('tfjs', 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.21.0/dist/tf.min.js', [], '3.21.0', true);
        wp_enqueue_script('faceapi', 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js', ['tfjs'], '0.22.2', true);
        wp_enqueue_script('staffapp', STAFFAPP_URL . 'assets/js/staffapp.js', ['faceapi'], STAFFAPP_VERSION, true);
        wp_localize_script('staffapp', 'STAFFAPP', [
            'api' => esc_url_raw(get_rest_url(null, 'staffapp/v1')),
            'photoUrl' => trailingslashit(wp_upload_dir()['baseurl']) . 'staffapp_photos/',
            'pluginUrl' => STAFFAPP_URL,
            'manifest' => STAFFAPP_URL . 'pwa/manifest.json',
            'sw' => STAFFAPP_URL . 'pwa/service-worker.js',
            'threshold' => 0.50,
        ]);
    }

    public static function render() {
        return '<link rel="manifest" href="' . esc_url(STAFFAPP_URL . 'pwa/manifest.json') . '"><meta name="theme-color" content="#0d0f14"><div id="staffapp-root"><div class="staffapp-loading"><b>ПРОХІДНА</b><br>Завантаження системи...</div></div>';
    }
}
