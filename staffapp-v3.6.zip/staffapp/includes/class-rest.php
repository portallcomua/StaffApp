<?php
if (!defined('ABSPATH')) exit;

class StaffApp_REST {
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'routes']);
    }

    public static function routes() {
        $ns = 'staffapp/v1';
        register_rest_route($ns, '/login', ['methods' => 'POST', 'callback' => [__CLASS__, 'login'], 'permission_callback' => '__return_true']);
        register_rest_route($ns, '/employees', ['methods' => 'GET', 'callback' => [__CLASS__, 'get_employees'], 'permission_callback' => [__CLASS__, 'can_use_app']]);
        register_rest_route($ns, '/employee', ['methods' => 'POST', 'callback' => [__CLASS__, 'save_employee'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/upload_photo', ['methods' => 'POST', 'callback' => [__CLASS__, 'upload_photo'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/fire', ['methods' => 'POST', 'callback' => [__CLASS__, 'fire_employee'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/restore', ['methods' => 'POST', 'callback' => [__CLASS__, 'restore_employee'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/delete', ['methods' => 'POST', 'callback' => [__CLASS__, 'delete_employee'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/attendance', ['methods' => 'POST', 'callback' => [__CLASS__, 'save_attendance'], 'permission_callback' => [__CLASS__, 'can_guard_or_manager']]);
        register_rest_route($ns, '/attendance', ['methods' => 'GET', 'callback' => [__CLASS__, 'get_attendance'], 'permission_callback' => [__CLASS__, 'can_use_app']]);
        register_rest_route($ns, '/attendance/by_employee', ['methods' => 'GET', 'callback' => [__CLASS__, 'get_attendance_by_employee'], 'permission_callback' => [__CLASS__, 'can_use_app']]);
        register_rest_route($ns, '/guards', ['methods' => 'GET', 'callback' => [__CLASS__, 'get_guards'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/guard', ['methods' => 'POST', 'callback' => [__CLASS__, 'save_guard'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/guard/update', ['methods' => 'POST', 'callback' => [__CLASS__, 'update_guard'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/guard/delete', ['methods' => 'POST', 'callback' => [__CLASS__, 'delete_guard'], 'permission_callback' => [__CLASS__, 'can_manager']]);
        register_rest_route($ns, '/export/employees', ['methods' => 'GET', 'callback' => [__CLASS__, 'export_employees'], 'permission_callback' => [__CLASS__, 'can_export']]);
        register_rest_route($ns, '/export/attendance', ['methods' => 'GET', 'callback' => [__CLASS__, 'export_attendance'], 'permission_callback' => [__CLASS__, 'can_export']]);
    }

    private static function token_from_request($request = null) {
        $token = '';
        if ($request && method_exists($request, 'get_header')) $token = $request->get_header('x-staffapp-token');
        if (!$token && isset($_GET['token'])) $token = sanitize_text_field(wp_unslash($_GET['token']));
        return sanitize_text_field($token);
    }

    public static function session($request = null) {
        $token = self::token_from_request($request);
        if (!$token) return false;
        $data = get_transient('staffapp_session_' . md5($token));
        return is_array($data) ? $data : false;
    }

    public static function can_use_app($request) { return (bool) self::session($request); }
    public static function can_manager($request) { $s = self::session($request); return $s && $s['role'] === 'manager'; }
    public static function can_guard_or_manager($request) { $s = self::session($request); return $s && in_array($s['role'], ['manager','guard'], true); }
    public static function can_export($request) { return self::can_manager($request); }

    public static function login($request) {
        global $wpdb;
        $data = $request->get_json_params();
        $role = sanitize_text_field($data['role'] ?? 'guard');
        $password = (string)($data['password'] ?? '');
        if ($password === '') return rest_ensure_response(['success' => false]);

        if ($role === 'manager') {
            $stored = $wpdb->get_var("SELECT setting_value FROM {$wpdb->prefix}staffapp_settings WHERE setting_key='manager_password'");
            if ($stored && wp_check_password($password, $stored)) {
                return self::make_session('manager', 'Керівник', 0);
            }
        } else {
            $guards = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}staffapp_guards ORDER BY id DESC");
            foreach ($guards as $g) {
                if (wp_check_password($password, $g->password)) return self::make_session('guard', $g->name, (int)$g->id);
            }
        }
        return rest_ensure_response(['success' => false]);
    }

    private static function make_session($role, $name, $id) {
        $token = wp_generate_password(48, false, false);
        set_transient('staffapp_session_' . md5($token), ['role' => $role, 'name' => $name, 'id' => $id], 12 * HOUR_IN_SECONDS);
        return rest_ensure_response(['success' => true, 'role' => $role, 'name' => $name, 'id' => $id, 'token' => $token]);
    }

    public static function get_employees() {
        global $wpdb;
        $items = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}staffapp_employees ORDER BY pib");
        $upload_url = trailingslashit(wp_upload_dir()['baseurl']) . 'staffapp_photos/';
        foreach ($items as $e) {
            $e->id = (int)$e->id;
            $e->fired = (int)$e->fired;
            $e->main_photo_raw = $e->main_photo;
            if ($e->main_photo && !filter_var($e->main_photo, FILTER_VALIDATE_URL)) $e->main_photo = $upload_url . $e->main_photo;
            $photos = json_decode($e->photos ?: '[]', true);
            $e->photos = is_array($photos) ? array_map(function($p) use ($upload_url) { return filter_var($p, FILTER_VALIDATE_URL) ? $p : $upload_url . $p; }, $photos) : [];
            $desc = json_decode($e->descriptors ?: '[]', true);
            $e->descriptors = is_array($desc) ? $desc : [];
        }
        return rest_ensure_response($items);
    }

    public static function upload_photo($request) {
        $data = $request->get_json_params();
        $base64 = (string)($data['photo'] ?? '');
        if (!preg_match('/^data:image\/(jpeg|jpg|png|webp);base64,/', $base64)) return rest_ensure_response(['success' => false, 'error' => 'Invalid image data']);
        $parts = explode(',', $base64, 2);
        $image = base64_decode($parts[1], true);
        if (!$image) return rest_ensure_response(['success' => false, 'error' => 'Base64 decode error']);
        if (strlen($image) > 7 * 1024 * 1024) return rest_ensure_response(['success' => false, 'error' => 'Image too large']);

        $employee_id = sanitize_file_name((string)($data['employee_id'] ?? 'temp'));
        $filename = 'emp_' . $employee_id . '_' . time() . '_' . wp_generate_password(8, false, false) . '.jpg';
        $dir = trailingslashit(wp_upload_dir()['basedir']) . 'staffapp_photos/';
        if (!file_exists($dir)) wp_mkdir_p($dir);
        $ok = file_put_contents($dir . $filename, $image);
        return rest_ensure_response(['success' => (bool)$ok, 'filename' => $filename]);
    }

    public static function save_employee($request) {
        global $wpdb;
        $data = $request->get_json_params();
        $pib = sanitize_text_field($data['pib'] ?? '');
        $posada = sanitize_text_field($data['posada'] ?? '');
        if (!$pib || !$posada) return rest_ensure_response(['success' => false, 'error' => 'ПІБ і посада обовʼязкові']);
        $descriptors = $data['descriptors'] ?? [];
        if (!is_array($descriptors) || count($descriptors) === 0) return rest_ensure_response(['success' => false, 'error' => 'Обличчя не розпізнано на фото. Зробіть якісніше фото.']);
        $photos = is_array($data['photos'] ?? null) ? array_map('sanitize_text_field', $data['photos']) : [];
        $main_photo = sanitize_text_field($data['main_photo'] ?? ($photos[0] ?? ''));
        $date_in = sanitize_text_field($data['date_in'] ?? current_time('Y-m-d'));
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}staffapp_employees WHERE pib=%s", $pib));
        $row = [
            'pib' => $pib, 'posada' => $posada, 'date_in' => $date_in, 'date_out' => null,
            'main_photo' => $main_photo, 'photos' => wp_json_encode($photos), 'descriptors' => wp_json_encode($descriptors), 'fired' => 0
        ];
        if ($exists) {
            $wpdb->update($wpdb->prefix . 'staffapp_employees', $row, ['id' => (int)$exists]);
            return rest_ensure_response(['success' => true, 'id' => (int)$exists]);
        }
        $ok = $wpdb->insert($wpdb->prefix . 'staffapp_employees', $row);
        return rest_ensure_response(['success' => (bool)$ok, 'id' => (int)$wpdb->insert_id, 'error' => $wpdb->last_error]);
    }

    public static function fire_employee($request) { return self::set_fired($request, 1); }
    public static function restore_employee($request) { return self::set_fired($request, 0); }
    private static function set_fired($request, $fired) {
        global $wpdb; $data = $request->get_json_params(); $id = (int)($data['id'] ?? 0);
        $wpdb->update($wpdb->prefix . 'staffapp_employees', ['fired' => $fired, 'date_out' => $fired ? current_time('Y-m-d') : null], ['id' => $id]);
        return rest_ensure_response(['success' => true]);
    }

    public static function delete_employee($request) {
        global $wpdb; $data = $request->get_json_params(); $id = (int)($data['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'staffapp_attendance', ['emp_id' => $id]);
        $wpdb->delete($wpdb->prefix . 'staffapp_employees', ['id' => $id]);
        return rest_ensure_response(['success' => true]);
    }

    public static function save_attendance($request) {
        global $wpdb; $data = $request->get_json_params(); $s = self::session($request);
        $type = sanitize_key($data['type'] ?? '');
        if (!in_array($type, ['in','out'], true)) return rest_ensure_response(['success' => false]);
        $ok = $wpdb->insert($wpdb->prefix . 'staffapp_attendance', [
            'emp_id' => (int)($data['emp_id'] ?? 0),
            'emp_name' => sanitize_text_field($data['emp_name'] ?? ''),
            'date' => current_time('Y-m-d'),
            'time' => current_time('H:i:s'),
            'type' => $type,
            'guard_name' => sanitize_text_field($s['name'] ?? ($data['guard_name'] ?? ''))
        ]);
        return rest_ensure_response(['success' => (bool)$ok]);
    }

    public static function get_attendance($request) {
        global $wpdb; $date = sanitize_text_field($request->get_param('date') ?: current_time('Y-m-d'));
        return rest_ensure_response($wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}staffapp_attendance WHERE date=%s ORDER BY time DESC", $date)));
    }

    public static function get_attendance_by_employee($request) {
        global $wpdb; $id = (int)$request->get_param('emp_id');
        return rest_ensure_response($wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}staffapp_attendance WHERE emp_id=%d ORDER BY date DESC,time DESC", $id)));
    }

    public static function get_guards() {
        global $wpdb;
        return rest_ensure_response($wpdb->get_results("SELECT id,name,created_at FROM {$wpdb->prefix}staffapp_guards ORDER BY id DESC"));
    }

    public static function save_guard($request) {
        global $wpdb; $data = $request->get_json_params();
        $name = sanitize_text_field($data['name'] ?? ''); $pwd = (string)($data['password'] ?? '');
        if (!$name || !$pwd) return rest_ensure_response(['success' => false]);
        $ok = $wpdb->insert($wpdb->prefix . 'staffapp_guards', ['name' => $name, 'password' => wp_hash_password($pwd)]);
        return rest_ensure_response(['success' => (bool)$ok, 'id' => (int)$wpdb->insert_id]);
    }

    public static function update_guard($request) {
        global $wpdb; $data = $request->get_json_params();
        $ok = $wpdb->update($wpdb->prefix . 'staffapp_guards', ['password' => wp_hash_password((string)$data['password'])], ['id' => (int)$data['id']]);
        return rest_ensure_response(['success' => $ok !== false]);
    }

    public static function delete_guard($request) {
        global $wpdb; $data = $request->get_json_params();
        $ok = $wpdb->delete($wpdb->prefix . 'staffapp_guards', ['id' => (int)$data['id']]);
        return rest_ensure_response(['success' => (bool)$ok]);
    }

    public static function export_employees() {
        global $wpdb; $items = $wpdb->get_results("SELECT id,pib,posada,date_in,date_out,fired FROM {$wpdb->prefix}staffapp_employees ORDER BY pib");
        self::csv_headers('employees_' . date('Y-m-d') . '.csv');
        echo "\xEF\xBB\xBFID,ПІБ,Посада,Дата прийняття,Дата звільнення,Статус\n";
        foreach ($items as $e) echo self::csv_line([$e->id, $e->pib, $e->posada, $e->date_in, $e->date_out ?: '—', $e->fired ? 'Звільнений' : 'Активний']);
        exit;
    }

    public static function export_attendance() {
        global $wpdb; $date = sanitize_text_field($_GET['date'] ?? date('Y-m-d'));
        $items = $wpdb->get_results($wpdb->prepare("SELECT a.*,e.posada FROM {$wpdb->prefix}staffapp_attendance a LEFT JOIN {$wpdb->prefix}staffapp_employees e ON a.emp_id=e.id WHERE a.date=%s ORDER BY a.time DESC", $date));
        self::csv_headers('attendance_' . $date . '.csv');
        echo "\xEF\xBB\xBFПІБ,Посада,Дата,Час,Подія,Охоронець\n";
        foreach ($items as $a) echo self::csv_line([$a->emp_name, $a->posada, $a->date, $a->time, $a->type === 'in' ? 'Прийшов' : 'Пішов', $a->guard_name]);
        exit;
    }

    private static function csv_headers($filename) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name($filename) . '"');
    }
    private static function csv_line($arr) {
        return implode(',', array_map(function($v){ return '"' . str_replace('"', '""', (string)$v) . '"'; }, $arr)) . "\n";
    }
}
