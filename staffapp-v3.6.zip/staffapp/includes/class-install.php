<?php
if (!defined('ABSPATH')) exit;

class StaffApp_Install {
    public static function activate() {
        self::create_tables();
        self::create_upload_dir();
        self::create_page();
    }

    public static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        $employees = $wpdb->prefix . 'staffapp_employees';
        $attendance = $wpdb->prefix . 'staffapp_attendance';
        $guards = $wpdb->prefix . 'staffapp_guards';
        $settings = $wpdb->prefix . 'staffapp_settings';

        dbDelta("CREATE TABLE $employees (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pib VARCHAR(255) NOT NULL,
            posada VARCHAR(255) NOT NULL,
            date_in DATE NULL,
            date_out DATE NULL,
            main_photo TEXT NULL,
            photos LONGTEXT NULL,
            descriptors LONGTEXT NULL,
            fired TINYINT(1) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY pib (pib(191)),
            KEY fired (fired)
        ) $charset;");

        dbDelta("CREATE TABLE $attendance (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            emp_id BIGINT UNSIGNED NULL,
            emp_name VARCHAR(255) NOT NULL,
            date DATE NOT NULL,
            time TIME NOT NULL,
            type VARCHAR(20) NOT NULL,
            guard_name VARCHAR(255) NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY date (date),
            KEY emp_id (emp_id)
        ) $charset;");

        dbDelta("CREATE TABLE $guards (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;");

        dbDelta("CREATE TABLE $settings (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(191) NOT NULL,
            setting_value LONGTEXT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) $charset;");

        if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM $settings WHERE setting_key=%s", 'manager_password'))) {
            $wpdb->insert($settings, ['setting_key' => 'manager_password', 'setting_value' => wp_hash_password('1111')]);
        }
        if (!$wpdb->get_var($wpdb->prepare("SELECT id FROM $settings WHERE setting_key=%s", 'company_name'))) {
            $wpdb->insert($settings, ['setting_key' => 'company_name', 'setting_value' => '']);
        }
    }

    public static function create_upload_dir() {
        $upload = wp_upload_dir();
        $dir = trailingslashit($upload['basedir']) . 'staffapp_photos';
        if (!file_exists($dir)) wp_mkdir_p($dir);
        if (!file_exists($dir . '/index.html')) file_put_contents($dir . '/index.html', '');
    }

    public static function create_page() {
        if (!get_page_by_path('staffapp')) {
            wp_insert_post([
                'post_title' => 'StaffApp',
                'post_name' => 'staffapp',
                'post_content' => '[staffapp]',
                'post_status' => 'publish',
                'post_type' => 'page'
            ]);
        }
    }
}
